﻿namespace Smart_E.Enums
{
    public enum Roles
    {
        Parent,
        Admin,
        Student,
        HOD,
        Teacher
    }
}
