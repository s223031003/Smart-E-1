﻿namespace Smart_E.Data
{
    public class DepartmentSubjects
    {
        public Guid Id { get; set; }

        public Guid DepartmentId { get; set; }

        public Guid CourseId { get; set; }


    }
}
