﻿namespace Smart_E.Data
{
    public class Departments
    {
        public Guid Id { get; set; }
        public string DepartmentName { get; set; }
        public string HODId { get;set; }
    }
}
