﻿namespace Smart_E.Models.Departments
{
    public class CreateDepartmentPostModal
    {
        public string Name { get; set; }

        public string Hod { get; set; }
    }
}
