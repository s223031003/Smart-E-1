﻿namespace Smart_E.Models.MyStudent
{
    public class UpdateStudentAttendancePostModal
    {
        public Guid Id { get; set; }

        public int NumberOfClassesAttended { get; set; }

    }
}
