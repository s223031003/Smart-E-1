﻿namespace Smart_E.Models
{
    public class ParentViewModel
    {
        public string Id { get; set; }
        public int NumberOfMessages { get; set; }
    }
}
