﻿namespace Smart_E.Models.Invites
{
    public class CreateParentInvitePostModal
    {
        public string Email { get; set; }
    }
}
