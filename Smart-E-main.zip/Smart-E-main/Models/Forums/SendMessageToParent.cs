﻿namespace Smart_E.Models.Forums
{
    public class SendMessageToParent
    {
        public string Message { get; set; }
        public string Parent { get; set; }
    }
}
