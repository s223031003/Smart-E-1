﻿namespace Smart_E.Models.Courses
{
    public class CourseViewModel
    {
        public Guid Id { get; set; }
        public string CourseName { get; set; }

        public string TeacherName { get; set; }
        public string Grade { get; set; }
    }
}
