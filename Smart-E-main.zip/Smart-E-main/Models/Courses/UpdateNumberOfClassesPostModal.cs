﻿namespace Smart_E.Models.Courses
{
    public class UpdateNumberOfClassesPostModal
    {
        public Guid Id { get; set; }

        public int NumberOfClasses { get; set; }
    }
}
