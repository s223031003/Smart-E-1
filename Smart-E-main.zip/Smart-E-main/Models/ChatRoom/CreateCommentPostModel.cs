﻿namespace Smart_E.Models.ChatRoom
{
    public class CreateCommentPostModel
    {
        public string Comment { get; set; }
    }
}
