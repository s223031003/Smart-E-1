﻿namespace Smart_E.Models.MyChild
{
    public class SendMessagePostModal
    {
        public string Message { get; set; }
    }
}
