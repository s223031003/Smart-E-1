﻿namespace Smart_E.Models.Teachers
{
    public class CreateTeacherPostModel
    {
        public string TeacherName { get; set; }
        public string Email { get; set; }
    }
}
