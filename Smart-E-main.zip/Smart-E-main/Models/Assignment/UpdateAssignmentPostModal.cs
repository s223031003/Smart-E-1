﻿namespace Smart_E.Models.Assignment
{
    public class UpdateAssignmentPostModal
    {
        public Guid Id { get; set; }

        public float NewMark{ get; set; }
        public bool Oustanding{ get; set; }

    }
}
