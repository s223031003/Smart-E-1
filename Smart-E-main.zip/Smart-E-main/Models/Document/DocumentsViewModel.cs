﻿namespace Smart_E.Models.NewFolder
{
    public class DocumentsViewModel
    {
    }
}
