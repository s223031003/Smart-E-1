﻿namespace Smart_E.Models.AllUsers
{
    public class ParentDetailsViewModel
    {
        public string Id { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

    }
}
