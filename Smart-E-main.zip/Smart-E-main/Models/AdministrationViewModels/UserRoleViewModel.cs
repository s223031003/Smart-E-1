﻿namespace Smart_E.Models.AdministrationViewModels
{
    public class UserRoleViewModel
    {

        public string Id { get; set; }

        public string Role { get; set; }
    }
}
