﻿using System.Drawing;
using DocumentFormat.OpenXml.Math;

namespace Smart_E.Models.AdministrationViewModels
{
    public class UpdateUserRolePostModal
    {
        public string Id { get; set; }
        public string Role { get; set; }

    }
}
