﻿using System.ComponentModel.DataAnnotations;

namespace Smart_E.Models.AdministrationViewModels
{
    public class LoginWithRecoveryCodeViewModel
    {
            [Required]
            [DataType(DataType.Text)]
            [Display(Name = "Recovery Code")]
            public string RecoveryCode { get; set; }
    }
}
